﻿namespace AnkitTest
{
    public class CTEResult
    {
        public int Id { get; set; }
        public int RoomClassId { get; set; }
        public string RoomClassName { get; set; }
    }
}